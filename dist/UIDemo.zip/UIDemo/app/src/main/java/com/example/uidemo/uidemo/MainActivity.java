package com.example.uidemo.uidemo;

import android.app.Activity;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.widget.ImageView;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends Activity {

    boolean moveingUp = true;
    ImageView sliderView;
    int maxY = 650;
    int minY = -400;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sliderView = (ImageView)findViewById(R.id.sliderView);

        // animate slider every 1/5 second
        new Timer().scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {

                int y = sliderView.getScrollY();

                if(moveingUp) {
                    y = y + 5;
                    if(y < maxY - 10) {

                        sliderView.setScrollY(y);

                    } else moveingUp = false;
                } else {
                    y = y - 5;
                    if(y > minY) {

                        sliderView.setScrollY(y);

                    } else moveingUp = true;
                }

            }
        }, 0, 200);
    }
}
